# King of HTTPD

```shell
docker build -t koh .
docker run -itd --name koh -p 44300:443 koh
```

