#include <stdio.h>
int main() {
    alarm(2);
    system("/bin/sh");
}
