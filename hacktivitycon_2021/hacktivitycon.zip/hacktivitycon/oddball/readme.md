# Write up
od is a tool like odd and hexdump. What we need to do is to recover Oct data to String.

