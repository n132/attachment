# write-up
write shellcode & a decoder
