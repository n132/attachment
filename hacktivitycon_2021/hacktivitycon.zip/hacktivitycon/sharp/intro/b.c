#include<stdio.h>
int main()
{
	char *a=malloc(0x18);
	char *b=malloc(0x18);
	free(b);
	read(0,a,100);
}

