#include<stdlib.h>
int main()
{
	malloc(0x18);
}
