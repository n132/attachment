# write-up
Stackoverflow+shellcode+socket
