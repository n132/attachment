# Write-up
There is a UAF in delete, and we have a backdoor function manage_items.
