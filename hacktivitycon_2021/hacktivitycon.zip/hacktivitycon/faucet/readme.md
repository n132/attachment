# write-up
format-str vul, leak the info by printf
